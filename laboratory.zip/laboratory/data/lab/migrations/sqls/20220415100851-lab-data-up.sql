/* Replace with your SQL commands */
INSERT INTO public.laboratory (test_type,doctor,patient,"time","date") VALUES ('regular','vasu','sneha','11:00:00','2020-01-01');
INSERT INTO public.laboratory(test_type, doctor, patient, "time", "date")VALUES( 'regular', 'vasu', 'ayushi', '10:00:00', '2020-01-01');
INSERT INTO public.laboratory( test_type, doctor, patient, "time", "date")VALUES('regular', 'vasu', 'sneha', '10:00:00', '2020-01-01');

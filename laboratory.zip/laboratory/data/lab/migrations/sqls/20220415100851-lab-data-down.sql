/* Replace with your SQL commands */
TRUNCATE TABLE laboratory;
/* Replace with your SQL commands */
DELETE FROM public.laboratory
WHERE id=nextval('laboratory_id_seq'::regclass);

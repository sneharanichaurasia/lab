

from lab import db


class Laboratory(db.Model):
    __tablename__ = 'laboratory'
    id = db.Column(db.Integer, primary_key=True)
    test_type = db.Column('test_type',db.String, nullable= True)
    date = db.Column('date', db.Date, nullable=False)
    time = db.Column('time', db.Time, nullable=False)
    doctor = db.Column(db.String,nullable=True)
    patient = db.Column(db.String,nullable=True)

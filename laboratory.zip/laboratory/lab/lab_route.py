import logging
import datetime

from flask import request, jsonify
from lab import app, db
from flask_cors import cross_origin
from lab.model import Laboratory

logging.basicConfig(filename='logs.log', level=logging.INFO)

''' DATE FORMATE FOR LABORATARY '''

def get_date(input_date):
    split_date = input_date.split("-")
    day = split_date[1]
    month = split_date[1]
    year = split_date[2]

    final_date = datetime.date(int(year), int(month), int(day))
    return final_date


'''CRUD OPERATIONS OF FOLLOWUP Laboratory '''


@app.route("/laboratory/api/lab", methods=['GET', 'OPTIONS'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])

def get_lab(*args):
    data = Laboratory.query.all()
    result = []
    for lab_data in data:
        lab_result = {}
        lab_result['id'] = lab_data.id
        lab_result['test_type'] = lab_data.test_type
        lab_result['time'] = str(lab_data.time)
        lab_result['date'] = str(lab_data.date)
        lab_result['doctor'] = lab_data.doctor
        lab_result['patient'] = lab_data.patient
        result.append(lab_result)
    return jsonify({'result': result})

'''lab post api'''



@app.route('/laboratory/api/lab_add', methods=['POST'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])
def add_exam(*args):
    lab_add = request.get_json()
    test_type = lab_add['test_type']
    date = lab_add['date']
    lab_add_date_formate = get_date(date)
    time = lab_add['time']
    patient = lab_add['patient']
    doctor = lab_add['doctor']
    lab_data = Laboratory(test_type = test_type, date = date, time = time, doctor = doctor, patient = patient )
    db.session.add(lab_data)
    db.session.commit()
    return "succesffully entered"

'''Lab put api'''
@app.route("/laboratory/api/lab/update/<id>", methods=['PUT', 'OPTIONS'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])

def get_lab_update(*args,id):
    request_data = request.get_json()
    test_type = request_data['test_type']
    time = request_data['time']
    date = request_data['date']
    doctor = request_data['doctor']
    patient = request_data['patient']
    request_data = Laboratory.query.filter_by(id=id).first()
    if not request_data:
        return jsonify({'message ': 'No user found'})
    request_data.time = time
    request_data.date = date
    request_data.doctor = doctor
    request_data.test_type = test_type
    db.session.commit()
    return jsonify({'lab updated successfully' : request_data.id})

'''lab schedule delete api'''

@app.route("/laboratory/api/lab/delete/<id>", methods=['DELETE', 'OPTIONS'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization'])
def lab_delete(*args, id):
    lab_data = Laboratory.query.filter_by(id=id).first()
    print(lab_data)
    if not lab_data:
        return jsonify({'message ': 'No data found'})
    db.session.delete(lab_data)
    db.session.commit()
    return jsonify({'candidate_deleted_successfully': lab_data.id})






